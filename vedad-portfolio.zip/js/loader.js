let loader = document.getElementById('loader');
let all = document.getElementById('site-wrapper');

setTimeout(function () {
    loader.style.display = 'none';
    all.style.display = 'block';
}, 3200);